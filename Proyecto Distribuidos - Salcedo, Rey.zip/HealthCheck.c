#include <zmq.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <locale.h>
#include <time.h>

struct RangoParametros {
    float minimo;
    float maximo;
};

void reemplazarNum(int numero, int lista[], int longitud, char tipoSensor[], char tipos[][12], time_t tiempos[]) {
    for (int i = 0; i < longitud; ++i) {
        if (lista[i] == -1) {
            lista[i] = numero;
            strncpy(tipos[i], tipoSensor, sizeof(tipos[i])-1);
            tipos[i][sizeof(tipos[i])-1] = '\0'; 
            tiempos[i] = time(NULL);
            return;
        }
    }
}

int encontrarPosicionEnLista(int numero, const int lista[], int longitud) {
    for (int i = 0; i < longitud; ++i) {
        if (lista[i] == numero) {
            return i; // Devuelve la posición del número en la lista
        }
    }
    return -1; // El número no está en la lista
}

int validarValor(float valor, const struct RangoParametros *rango) {
    return (valor >= rango->minimo && valor <= rango->maximo);
}

void revisarPID(char *mensaje, char tipos[5][12], time_t tiempos[5], int pids[5]){
    char tipoSensor[12] = "\0";
    int pid;
    if (sscanf(mensaje, "PID: %d, Tipo Sensor: %s", &pid, tipoSensor) == 2) {
        printf("PID: %d, Tipo Sensor: %s\n", pid, tipoSensor);

        int posicion = encontrarPosicionEnLista(pid, pids, 5);

        if (posicion != -1) {
            tiempos[posicion] = time(NULL);
        } else {
            reemplazarNum(pid, pids, 5, tipoSensor, tipos, tiempos);
        }

            
    }
}

void enviarAlarmaSistemaCalidad(void *socket, const char *mensaje, const char *hora) {
    char mensajeConHora[150];
    snprintf(mensajeConHora, sizeof(mensajeConHora), "%s - Hora de la alarma: %s", mensaje, hora);
    zmq_send(socket, mensajeConHora, strlen(mensajeConHora), 0);
}

void recibirInfo(void *socket, FILE *archivoRegistro, const char *tipoSensor, const struct RangoParametros *rango, void *socketSistemaCalidad) {
    char mensaje[100];
    zmq_recv(socket, mensaje, sizeof(mensaje), 0);

    // Parsear el valor desde el mensaje (puedes utilizar sscanf)
    char sensorTipo[20];
    float valor;
    char unidad[20];

    if (sscanf(mensaje, "%[^:]: %f %[^\n]", sensorTipo, &valor, unidad) == 3) {
        if (valor >= 0) {
            int esValido = validarValor(valor, rango);

            if (strcmp(sensorTipo, tipoSensor) == 0) {
                printf("Monitor recibió: %s\n", mensaje);
                fprintf(archivoRegistro, "%s\n", mensaje);
                fflush(archivoRegistro);

                if (!esValido) {
                    printf("Valor de %s fuera de rango. Alarma generada.\n", tipoSensor);
                    char mensajeAlarma[100];
                    snprintf(mensajeAlarma, sizeof(mensajeAlarma), "ALARMA: %s fuera de rango", tipoSensor);

                    // Obtener la hora del mensaje
                    char hora[9];  // Asumiendo que la hora tiene 8 caracteres (HH:MM:SS)
                    if (sscanf(mensaje, "%*[^:]:%*f - Hora: %[^\n]", hora) == 1) {
                        enviarAlarmaSistemaCalidad(socketSistemaCalidad, mensajeAlarma, hora);
                    } else {
                        printf("Error al extraer la hora del mensaje. La alarma se enviará sin la hora.\n");
                        enviarAlarmaSistemaCalidad(socketSistemaCalidad, mensajeAlarma, "Hora no disponible");
                    }
                }
            }
        } else {
            char hora[9]; 
            if (sscanf(mensaje, "%*[^:]:%*f - Hora: %[^\n]", hora) == 1) {
                printf("Valor erróneo en el mensaje. Alarma generada.\n");
                char mensajeAlarma[100];
                snprintf(mensajeAlarma, sizeof(mensajeAlarma), "ALARMA: %s fuera de rango", tipoSensor);
                enviarAlarmaSistemaCalidad(socketSistemaCalidad, mensajeAlarma, hora);
            } else {
                char mensajeAlarma[100];
                snprintf(mensajeAlarma, sizeof(mensajeAlarma), "ALARMA: %s fuera de rango", tipoSensor);
                printf("Error al extraer la hora del mensaje. La alarma se enviará sin la hora.\n");
                enviarAlarmaSistemaCalidad(socketSistemaCalidad, mensajeAlarma, "Hora no disponible");
            }
            
        }
    }
}


int main() {
    struct RangoParametros *rango;
    struct RangoParametros rangosTemperatura = {68.0, 89.0};
    struct RangoParametros rangosPH = {6.0, 8.0};
    struct RangoParametros rangosOxigeno = {2.0, 11.0};

    FILE *archivoRegistro;
    char nombreArchivo[50];


    void *contextLatido = zmq_ctx_new();
    void *socketLatido = zmq_socket(contextLatido, ZMQ_SUB);
    for (int puerto = 5591; puerto <= 5615; puerto++) {
        char direccion[50];
        snprintf(direccion, sizeof(direccion), "tcp://192.168.5.133:%d", puerto);

        // Conectar al sensor
        zmq_connect(socketLatido, direccion);
    }
    zmq_setsockopt(socketLatido, ZMQ_SUBSCRIBE, "", 0);

    void *context = zmq_ctx_new();
    void *socket = zmq_socket(context, ZMQ_SUB);
    for (int puerto = 5555; puerto <= 5575; puerto++) {
        char direccion[50];
        snprintf(direccion, sizeof(direccion), "tcp://192.168.5.132:%d", puerto);

        // Conectar al sensor
        zmq_connect(socket, direccion);
    }
    zmq_setsockopt(socket, ZMQ_SUBSCRIBE, "", 0);

    //Sistema de calidad

    int puertoSistemaCalidad;

    FILE *puertoFile = fopen("puertoSistemaCalidad.txt", "r");

    if (puertoFile == NULL) {
        printf("No se pudo abrir el archivo de puerto.\n");
        return 1;
    }

    if (fscanf(puertoFile, "%d", &puertoSistemaCalidad) != 1) {
        printf("Error al leer el archivo de puerto.\n");
        fclose(puertoFile);
        return 1;
    }

    fclose(puertoFile);

    void *contextSistemaCalidad = zmq_ctx_new();
    void *socketSistemaCalidad = zmq_socket(contextSistemaCalidad, ZMQ_PUB);

    char direccion[50];
    snprintf(direccion, sizeof(direccion), "tcp://192.168.5.133:%d", puertoSistemaCalidad);

    if (zmq_bind(socketSistemaCalidad, direccion) != 0) {
        printf("Error al enlazar el socket al puerto %d.\n", puertoSistemaCalidad);
        zmq_close(socketSistemaCalidad);
        zmq_ctx_destroy(contextSistemaCalidad);
        return 1;
    }

    puertoSistemaCalidad++;
    FILE *puertoFileWrite = fopen("puertoSistemaCalidad.txt", "w");

    if (puertoFileWrite == NULL) {
        printf("No se pudo abrir el archivo de puerto para escritura.\n");
        zmq_close(socketSistemaCalidad);
        zmq_ctx_destroy(contextSistemaCalidad);
        return 1;
    }

    fprintf(puertoFileWrite, "%d", puertoSistemaCalidad);
    fclose(puertoFileWrite);

    // Variables para almacenar la información del PID y del tipo de sensor
    // Valor inicial no válido
    
    int pid[5] = {-1, -1, -1, -1, -1};
    time_t tiempos[5];
    char tipos [5][12];
    // Establecer un temporizador para verificar los latidos del monitor
    int bandera = 1;

    printf("Esperando latidos...\n");
    while (1) {
        char mensaje[50];
        int resultado = zmq_recv(socketLatido, mensaje, sizeof(mensaje), ZMQ_NOBLOCK);

        if (resultado > 0) 
            revisarPID(mensaje, tipos, tiempos, pid);


        // Verificar si han pasado 3 segundos sin recibir un latido
        for(int i = 0; i < 5; ++i){
            if(pid[i] != -1){
                if ((difftime(time(NULL), tiempos[i]) >= 3) && (difftime(time(NULL), tiempos[i]) < 10)) {
                    printf("¡No se ha recibido un latido en los últimos 3 segundos! Realizar alguna acción aquí.\n");
                    printf("tipo: %s", tipos[i]);
                    if (strcmp(tipos[i], "temperatura") == 0) {
                        rango = &rangosTemperatura;
                    } else if (strcmp(tipos[i], "ph") == 0) {
                        rango = &rangosPH;
                    } else if (strcmp(tipos[i], "oxigeno") == 0) {
                        rango = &rangosOxigeno;
                    } else {
                        printf("Tipo de sensor no válido.\n");
                        return 1;
                    }
                    snprintf(nombreArchivo, sizeof(nombreArchivo), "registro_%s.txt", tipos[i]);

                    archivoRegistro = fopen(nombreArchivo, "a");  // Abre el archivo de registro en modo anexar

                    if (!archivoRegistro) {
                        perror("Error al abrir el archivo de registro");
                        return 1;
                    }
                    recibirInfo(socket, archivoRegistro, tipos[i], rango, socketSistemaCalidad);
                    fclose(archivoRegistro);
                }

                if (difftime(time(NULL), tiempos[i]) >= 10){
                    pid[i] = -1;
                }
            }
        }
        // Pausa para evitar un bucle de ocupación de la CPU
        usleep(100000); // 100,000 microsegundos = 0,1 segundos
    }

    printf("Se terminó el HealthCheck\n");
    zmq_close(socketLatido);
    zmq_ctx_destroy(contextLatido);

    return 0;
}
