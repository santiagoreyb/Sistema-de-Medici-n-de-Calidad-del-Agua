#include <zmq.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <locale.h>

struct RangoParametros {
    float minimo;
    float maximo;
};

float generarMedidaTemperatura(float probabilidadCorrecta, float probabilidadFueraRango, float probabilidadError) {
    float r = (float)rand() / RAND_MAX;
    if (r < probabilidadCorrecta) {
        return 68.0 + ((float)rand() / RAND_MAX) * (89.0 - 68.0);
    } else if (r < probabilidadCorrecta + probabilidadFueraRango) {
        return (float)rand() / RAND_MAX * (110.0 - (-10.0)) - 10.0;
    } else {
        return -1; // Valor inválido (error)
    }
}

float generarMedidaPH(float probabilidadCorrecta, float probabilidadFueraRango, float probabilidadError) {
    float r = (float)rand() / RAND_MAX;
    if (r < probabilidadCorrecta) {
        return 6.0 + ((float)rand() / RAND_MAX) * (8.0 - 6.0);
    } else if (r < probabilidadCorrecta + probabilidadFueraRango) {
        return (float)rand() / RAND_MAX * (10.0 - 4.0) + 4.0;
    } else {
        return -1; // Valor inválido (error)
    }
}

float generarMedidaOxigeno(float probabilidadCorrecta, float probabilidadFueraRango, float probabilidadError) {
    float r = (float)rand() / RAND_MAX;
    if (r < probabilidadCorrecta) {
        return 2.0 + ((float)rand() / RAND_MAX) * (11.0 - 2.0);
    } else if (r < probabilidadCorrecta + probabilidadFueraRango) {
        return (float)rand() / RAND_MAX * (15.0 - 1.0) + 1.0;
    } else {
        return -1; // Valor inválido (error)
    }
}

void mandarMensaje(char *tipoSensor, char *horaActual, float medida, void *socket) {
    char mensaje[100];
    snprintf(mensaje, sizeof(mensaje), "%s: %.2f - Hora: %s", tipoSensor, medida, horaActual);

    zmq_send(socket, mensaje, strlen(mensaje), 0);
}

void obtenerHoraActual(char *horaActual) {
    time_t tiempo;
    struct tm *infoTiempo;

    time(&tiempo);
    infoTiempo = localtime(&tiempo);

    strftime(horaActual, 20, "%I:%M:%S", infoTiempo);

    if (infoTiempo->tm_hour >= 12) {
        strcat(horaActual, " p.m.");
    } else {
        strcat(horaActual, " a.m.");
    }
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Uso: %s <tipo_sensor> <intervalo_tiempo> <archivo_configuracion>\n", argv[0]);
        return 1;
    }

    char *tipoSensor = argv[1];
    int intervaloTiempo = atoi(argv[2]);
    char *archivoConfiguracion = argv[3];

    // Leer las probabilidades desde el archivo de configuración
    float probabilidadCorrecta, probabilidadFueraRango, probabilidadError;

    FILE *configFile = fopen(archivoConfiguracion, "r");

    if (configFile == NULL) {
        printf("No se pudo abrir el archivo de configuración.\n");
        return 1;
    }

    if (fscanf(configFile, "%f %f %f", &probabilidadCorrecta, &probabilidadFueraRango, &probabilidadError) != 3) {
        printf("Error al leer el archivo de configuración.\n");
        fclose(configFile);
        return 1;
    }

    fclose(configFile);

    // Leer el número de puerto desde el archivo "puerto.txt"
    int puerto;

    FILE *puertoFile = fopen("puerto.txt", "r");

    if (puertoFile == NULL) {
        printf("No se pudo abrir el archivo de puerto.\n");
        return 1;
    }

    if (fscanf(puertoFile, "%d", &puerto) != 1) {
        printf("Error al leer el archivo de puerto.\n");
        fclose(puertoFile);
        return 1;
    }

    fclose(puertoFile);

    // Configura la localización para admitir caracteres acentuados
    setlocale(LC_ALL, "en_US.UTF-8");

    void *context = zmq_ctx_new();
    void *socket = zmq_socket(context, ZMQ_PUB);

    char direccion[50];
    snprintf(direccion, sizeof(direccion), "tcp://192.168.10.23:%d", puerto);

    if (zmq_bind(socket, direccion) != 0) {
        printf("Error al enlazar el socket al puerto %d.\n", puerto);
        zmq_close(socket);
        zmq_ctx_destroy(context);
        return 1;
    }

    // Incrementar el valor del puerto en 1 y escribirlo en el archivo
    puerto++;
    FILE *puertoFileWrite = fopen("puerto.txt", "w");

    if (puertoFileWrite == NULL) {
        printf("No se pudo abrir el archivo de puerto para escritura.\n");
        zmq_close(socket);
        zmq_ctx_destroy(context);
        return 1;
    }

    fprintf(puertoFileWrite, "%d", puerto);
    fclose(puertoFileWrite);

    srand(time(NULL));

    while (1) {
        float medida;
        char horaActual[30];

        obtenerHoraActual(horaActual);

        if (strcmp(tipoSensor, "temperatura") == 0) {
            medida = generarMedidaTemperatura(probabilidadCorrecta, probabilidadFueraRango, probabilidadError);
        } else if (strcmp(tipoSensor, "ph") == 0) {
            medida = generarMedidaPH(probabilidadCorrecta, probabilidadFueraRango, probabilidadError);
        } else if (strcmp(tipoSensor, "oxigeno") == 0) {
            medida = generarMedidaOxigeno(probabilidadCorrecta, probabilidadFueraRango, probabilidadError);
        } else {
            printf("Tipo de sensor no válido.\n");
            return 1;
        }

        mandarMensaje(tipoSensor, horaActual, medida, socket);

        sleep(intervaloTiempo);
    }

    zmq_close(socket);
    zmq_ctx_destroy(context);

    return 0;
}