Para el correcto funcionamiento del proyecto hay que tener varias cosas en cuenta:
    1. El orden:
        -Primero se deben encender los Sensotes
        -Posteriormente los monitores
        -Después el HealthCheck
        -PAra finalizar el Sistema de Calidad
    2. Los puertos:
        - Hay 3 archivos de puertos:
            -puerto.txt (5555 - 5575)
            -puertoSistemaCalidad (5576 - 5590)
            -puertoMonitor (5591 - 5610)
        - En caso de que estos archivos de texto superen el numero esperado hay que reiniciarlos para un correcto funcionamiento del Sistema
    3. Si se quiere simular una caida de un Monitor hay que descomentar la alarma del Monitor anterior al while y volver a hacer el gcc