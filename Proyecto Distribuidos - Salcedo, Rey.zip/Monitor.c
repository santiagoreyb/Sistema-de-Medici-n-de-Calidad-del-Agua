#include <zmq.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <locale.h>
#include <signal.h>

struct RangoParametros {
    float minimo;
    float maximo;
};

int tiempoLímiteAlcanzado = 0;

// Función para manejar la señal de alarma
void manejarAlarma(int signal) {
    sleep(15);
}

int validarValor(float valor, const struct RangoParametros *rango) {
    return (valor >= rango->minimo && valor <= rango->maximo);
}

void enviarAlarmaSistemaCalidad(void *socket, const char *mensaje, const char *hora) {
    char mensajeConHora[150];
    snprintf(mensajeConHora, sizeof(mensajeConHora), "%s - Hora de la alarma: %s", mensaje, hora);
    zmq_send(socket, mensajeConHora, strlen(mensajeConHora), 0);
}

void recibirInfo(void *socket, FILE *archivoRegistro, const char *tipoSensor, const struct RangoParametros *rango, void *socketSistemaCalidad) {
    char mensaje[100];
    zmq_recv(socket, mensaje, sizeof(mensaje), 0);

    // Parsear el valor desde el mensaje (puedes utilizar sscanf)
    char sensorTipo[20];
    float valor;
    char unidad[20];

    if (sscanf(mensaje, "%[^:]: %f %[^\n]", sensorTipo, &valor, unidad) == 3) {
        if (valor >= 0) {
            int esValido = validarValor(valor, rango);

            if (strcmp(sensorTipo, tipoSensor) == 0) {
                printf("Monitor recibió: %s\n", mensaje);
                fprintf(archivoRegistro, "%s\n", mensaje);
                fflush(archivoRegistro);

                if (!esValido) {
                    printf("Valor de %s fuera de rango. Alarma generada.\n", tipoSensor);
                    char mensajeAlarma[100];
                    snprintf(mensajeAlarma, sizeof(mensajeAlarma), "ALARMA: %s fuera de rango", tipoSensor);

                    // Obtener la hora del mensaje
                    char hora[9];  // Asumiendo que la hora tiene 8 caracteres (HH:MM:SS)
                    if (sscanf(mensaje, "%*[^:]:%*f - Hora: %[^\n]", hora) == 1) {
                        enviarAlarmaSistemaCalidad(socketSistemaCalidad, mensajeAlarma, hora);
                    } else {
                        printf("Error al extraer la hora del mensaje. La alarma se enviará sin la hora.\n");
                        enviarAlarmaSistemaCalidad(socketSistemaCalidad, mensajeAlarma, "Hora no disponible");
                    }
                }
            }
        } else {
            char hora[9]; 
            if (sscanf(mensaje, "%*[^:]:%*f - Hora: %[^\n]", hora) == 1) {
                printf("Valor erróneo en el mensaje. Alarma generada.\n");
                char mensajeAlarma[100];
                snprintf(mensajeAlarma, sizeof(mensajeAlarma), "ALARMA: %s fuera de rango", tipoSensor);
                enviarAlarmaSistemaCalidad(socketSistemaCalidad, mensajeAlarma, hora);
            } else {
                char mensajeAlarma[100];
                snprintf(mensajeAlarma, sizeof(mensajeAlarma), "ALARMA: %s fuera de rango", tipoSensor);
                printf("Error al extraer la hora del mensaje. La alarma se enviará sin la hora.\n");
                enviarAlarmaSistemaCalidad(socketSistemaCalidad, mensajeAlarma, "Hora no disponible");
            }
            
        }
    }
}

void enviarInfoMonitor(void *socket, char *tipoSensor) {
    pid_t pid = getpid();
    char mensaje[50];
    snprintf(mensaje, sizeof(mensaje), "PID: %d, Tipo Sensor: %s", pid, tipoSensor);
    printf("%s\n", mensaje);
    zmq_send(socket, mensaje, strlen(mensaje), 0);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Uso: %s <tipo_sensor>\n", argv[0]);
        return 1;
    }

    char *tipoSensor = argv[1];

    //Sensor

    void *context = zmq_ctx_new();
    void *socket = zmq_socket(context, ZMQ_SUB);

    for (int puerto = 5555; puerto <= 5575; puerto++) {
        char direccion[50];
        snprintf(direccion, sizeof(direccion), "tcp://192.168.5.132:%d", puerto);

        // Conectar al sensor
        zmq_connect(socket, direccion);
    }

    zmq_setsockopt(socket, ZMQ_SUBSCRIBE, tipoSensor, strlen(tipoSensor));

    //Sistema de Calidad

    
    int puertoSistemaCalidad;

    FILE *puertoFileSistemaCalidad = fopen("puertoSistemaCalidad.txt", "r");

    if (puertoFileSistemaCalidad == NULL) {
        printf("No se pudo abrir el archivo de puerto.\n");
        return 1;
    }

    if (fscanf(puertoFileSistemaCalidad, "%d", &puertoSistemaCalidad) != 1) {
        printf("Error al leer el archivo de puerto.\n");
        fclose(puertoFileSistemaCalidad);
        return 1;
    }

    fclose(puertoFileSistemaCalidad);

    void *contextSistemaCalidad = zmq_ctx_new();
    void *socketSistemaCalidad = zmq_socket(contextSistemaCalidad, ZMQ_PUB);

    char direccion[50];
    snprintf(direccion, sizeof(direccion), "tcp://192.168.5.133:%d", puertoSistemaCalidad);

    if (zmq_bind(socketSistemaCalidad, direccion) != 0) {
        printf("Error al enlazar el socket al puerto %d.\n", puertoSistemaCalidad);
        zmq_close(socketSistemaCalidad);
        zmq_ctx_destroy(contextSistemaCalidad);
        return 1;
    }

    puertoSistemaCalidad++;
    FILE *puertoFileWriteSistemaCalidad = fopen("puertoSistemaCalidad.txt", "w");

    if (puertoFileWriteSistemaCalidad == NULL) {
        printf("No se pudo abrir el archivo de puerto para escritura.\n");
        zmq_close(socketSistemaCalidad);
        zmq_ctx_destroy(contextSistemaCalidad);
        return 1;
    }

    fprintf(puertoFileWriteSistemaCalidad, "%d", puertoSistemaCalidad);
    fclose(puertoFileWriteSistemaCalidad);

    //Monitor

    int puertoMonitor;

    FILE *puertoFileMonitor = fopen("puertoMonitor.txt", "r");

    if (puertoFileMonitor == NULL) {
        printf("No se pudo abrir el archivo de puerto.\n");
        return 1;
    }

    if (fscanf(puertoFileMonitor, "%d", &puertoMonitor) != 1) {
        printf("Error al leer el archivo de puerto.\n");
        fclose(puertoFileMonitor);
        return 1;
    }

    fclose(puertoFileMonitor);

    void *contextMonitor = zmq_ctx_new();
    void *socketMonitor = zmq_socket(contextMonitor, ZMQ_PUB);

    snprintf(direccion, sizeof(direccion), "tcp://192.168.5.133:%d", puertoMonitor);

    if (zmq_bind(socketMonitor, direccion) != 0) {
        printf("Error al enlazar el socket al puerto %d.\n", puertoMonitor);
        zmq_close(socketMonitor);
        zmq_ctx_destroy(contextMonitor);
        return 1;
    }

    puertoMonitor++;
    FILE *puertoFileWriteMonitor = fopen("puertoMonitor.txt", "w");

    if (puertoFileWriteMonitor == NULL) {
        printf("No se pudo abrir el archivo de puerto para escritura.\n");
        zmq_close(socketMonitor);
        zmq_ctx_destroy(contextMonitor);
        return 1;
    }

    fprintf(puertoFileWriteMonitor, "%d", puertoMonitor);
    fclose(puertoFileWriteMonitor);

    // Suscribirse a los mensajes del tipo de sensor

    FILE *archivoRegistro;
    char nombreArchivo[50];
    snprintf(nombreArchivo, sizeof(nombreArchivo), "registro_%s.txt", tipoSensor);

    archivoRegistro = fopen(nombreArchivo, "a");  // Abre el archivo de registro en modo anexar

    if (!archivoRegistro) {
        perror("Error al abrir el archivo de registro");
        return 1;
    }

    // Configura la localización para admitir caracteres acentuados
    setlocale(LC_ALL, "en_US.UTF-8");

    struct RangoParametros rangosTemperatura = {68.0, 89.0};
    struct RangoParametros rangosPH = {6.0, 8.0};
    struct RangoParametros rangosOxigeno = {2.0, 11.0};

    const struct RangoParametros *rango;

    if (strcmp(tipoSensor, "temperatura") == 0) {
        rango = &rangosTemperatura;
    } else if (strcmp(tipoSensor, "ph") == 0) {
        rango = &rangosPH;
    } else if (strcmp(tipoSensor, "oxigeno") == 0) {
        rango = &rangosOxigeno;
    } else {
        printf("Tipo de sensor no válido.\n");
        return 1;
    }

    signal(SIGALRM, manejarAlarma);

    // Establece la alarma para que en 20 segundos el monitor haga un sleep
    //alarm(20);



    while (tiempoLímiteAlcanzado == 0) {
        recibirInfo(socket, archivoRegistro, tipoSensor, rango, socketSistemaCalidad);

        sleep(1);

        enviarInfoMonitor(socketMonitor, tipoSensor);
    }

    fclose(archivoRegistro);
    zmq_close(socket);
    zmq_close(socketSistemaCalidad);
    zmq_close(socketMonitor);
    zmq_ctx_destroy(context);
    zmq_ctx_destroy(contextSistemaCalidad);
    zmq_ctx_destroy(contextMonitor);


    return 0;
}
