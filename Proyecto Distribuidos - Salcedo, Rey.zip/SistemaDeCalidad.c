#include <zmq.h>
#include <stdio.h>
#include <time.h>

int main() {
    void *context = zmq_ctx_new();
    void *socket = zmq_socket(context, ZMQ_SUB);
    
    for (int puerto = 5576; puerto <= 5590; puerto++) {
        char direccion[50];
        snprintf(direccion, sizeof(direccion), "tcp://192.168.5.133:%d", puerto);

        // Conectar al sensor
        zmq_connect(socket, direccion);
    }
    
    // Suscribirse a todos los mensajes (cualquier filtro)
    zmq_setsockopt(socket, ZMQ_SUBSCRIBE, "", 0);

    // Enlazar el socket a un puerto específico (ajusta según tus necesidades)
    printf("Esperando mensaje...\n");
    while (1) {
        char mensaje[100];
        zmq_recv(socket, mensaje, sizeof(mensaje), 0);
        printf("Sistema de Calidad recibió: %s\n", mensaje);

        // Obtener la hora actual
        time_t tiempo_actual = time(NULL);
        struct tm *info_tiempo = localtime(&tiempo_actual);
        char tiempo_formateado[80];
        strftime(tiempo_formateado, sizeof(tiempo_formateado), "%Y-%m-%d %H:%M:%S", info_tiempo);

        printf("[%s] Hora actual\n", tiempo_formateado);
    }
    
    zmq_close(socket);
    zmq_ctx_destroy(context);

    return 0;
}
